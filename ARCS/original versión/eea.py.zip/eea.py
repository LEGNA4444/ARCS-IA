import os
import time

class ARCS:
    def __init__(self):
        self.ruta_base = "/storage/emulated/0/urc/urc/"
        self.archivo_memoria = self.ruta_base + "arcs_v2_core.txt"
        self.archivo_dicc = self.ruta_base + "arcs_v2_dict.txt"
        self.archivo_pesos = self.ruta_base + "arcs_pesos.txt"
        
        self.neuronas = 5120
        self.capas = 5
        self.memoria = {} 
        self.diccionario = {}
        self.prioridades = {} 
        
        if not os.path.exists(self.ruta_base):
            os.makedirs(self.ruta_base, exist_ok=True)
        self.boot_permanente()

    def boot_permanente(self):
        for ruta, obj in [(self.archivo_dicc, self.diccionario), 
                          (self.archivo_memoria, self.memoria),
                          (self.archivo_pesos, self.prioridades)]:
            if os.path.exists(ruta):
                with open(ruta, "r", encoding="utf-8") as f:
                    for l in f:
                        sep = "::" if "::" in l else ">"
                        if sep in l:
                            parts = l.split(sep)
                            if len(parts) == 2:
                                k, v = parts
                                if sep == ">": 
                                    obj[k.strip()] = v.strip().split(",")
                                else: 
                                    obj[k.strip()] = v.strip()

    def limpiar(self, t):
        p = "abcdefghijklmnopqrstuvwxyz0123456789ñáéíóú "
        return "".join([c for c in str(t).lower() if c in p]).strip()

    def aprender(self, t):
        palabras = self.limpiar(t).split()
        if len(palabras) < 2: return
        
        # Conceptos de importancia para la transferencia de pesos
        conceptos_clave = ["lealtad", "clika", "respeto", "gringos", "codigo", "fuerza"]
        
        for i in range(len(palabras) - 1):
            a, s = palabras[i], palabras[i+1]
            if a not in self.memoria: self.memoria[a] = []
            if s not in self.memoria[a]: self.memoria[a].append(s)
            
            # Lógica de Herencia de Importancia:
            # Si una palabra está cerca de un concepto clave, gana relevancia
            for clave in conceptos_clave:
                if clave in palabras:
                    self.prioridades[a] = str(int(self.prioridades.get(a, 0)) + 1)
                    break
            
            if a not in self.diccionario:
                self.diccionario[a] = s
        self.guardar_indestructible()

    def responder(self, t):
        palabras = self.limpiar(t).split()
        if not palabras: return "arcs online"
        
        # Búsqueda del "Enfoque Conceptual"
        enfoque = palabras[0]
        max_p = -1
        for p in palabras:
            p_val = int(self.prioridades.get(p, 0))
            if p_val > max_p:
                enfoque = p
                max_p = p_val
        
        res = []
        actual = enfoque
        # Semilla basada en tiempo y contexto para evitar bucles infinitos
        semilla = int(time.time()) % self.neuronas
        
        for _ in range(35):
            if actual in self.memoria:
                opciones = self.memoria[actual]
                # Modificamos la semilla para que sea más dinámica
                semilla = (semilla * 31337 + 7) % 1000000
                
                # Elegimos la opción más pesada si existe en el diccionario
                proximo = opciones[semilla % len(opciones)]
                
                if len(res) > 1 and proximo == res[-1]: continue
                res.append(proximo)
                actual = proximo
                
                # Corte lógico de frase
                if len(res) > 8 and actual in self.diccionario and semilla % 3 == 0:
                    break
            else: break
            
        return " ".join(res) if res else "sistema analizando entorno"

    def guardar_indestructible(self):
        try:
            with open(self.archivo_dicc, "w", encoding="utf-8") as f:
                for k, v in self.diccionario.items():
                    f.write(f"{k} :: {v}\n")
            with open(self.archivo_memoria, "w", encoding="utf-8") as f:
                for k, v in self.memoria.items():
                    f.write(f"{k}>{','.join(v)}\n")
            with open(self.archivo_pesos, "w", encoding="utf-8") as f:
                for k, v in self.prioridades.items():
                    f.write(f"{k} :: {v}\n")
        except Exception:
            pass

# --- EJECUCIÓN ---
arcs = ARCS()
print("ARCS v2.5 MOD-REAL: Conciencia de Contexto Activa")
while True:
    try:
        u = input("[Tú]: ")
        if u.lower() in ["exit", "salir"]: break
        arcs.aprender(u)
        respuesta = arcs.responder(u)
        print(f"[ARCS]: {respuesta}")
    except EOFError: break
